from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Allow CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"message": "SafeWeb API running"}

@app.get("/scan")
def scan():
    return {"status": "success", "result": "No vulnerabilities found"}

@app.get("/alerts")
def alerts():
    return {"alerts": [
        {"id": 1, "type": "SQL Injection", "severity": "High"},
        {"id": 2, "type": "XSS Attack", "severity": "Medium"}
    ]}

@app.get("/compliance")
def compliance():
    return {"compliance": "System compliant with basic security standards"}
