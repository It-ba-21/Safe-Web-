import React from 'react'
import Dashboard from './components/Dashboard'

export default function App() {
  return (
    <div>
      <h1 style={{textAlign:"center"}}>SafeWeb Cybersecurity Dashboard</h1>
      <Dashboard />
    </div>
  )
}
