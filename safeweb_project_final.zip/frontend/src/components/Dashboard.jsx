import React, { useEffect, useState } from 'react'

export default function Dashboard() {
  const [alerts, setAlerts] = useState([])

  useEffect(() => {
    fetch('/api/alerts')
      .then(res => res.json())
      .then(data => setAlerts(data.alerts || []))
  }, [])

  return (
    <div style={{padding:"20px"}}>
      <h2>Threat Alerts</h2>
      <ul>
        {alerts.map(alert => (
          <li key={alert.id}>
            {alert.type} - Severity: {alert.severity}
          </li>
        ))}
      </ul>
    </div>
  )
}
