# SafeWeb – Cybersecurity SaaS for SMEs

This project provides a simple SaaS-style cybersecurity dashboard with FastAPI backend and React frontend.

## Backend
- FastAPI with SQLite
- Endpoints: `/scan`, `/alerts`, `/compliance`

Run:
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## Frontend
- React (Vite)
- Connects to backend via proxy

Run:
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```
